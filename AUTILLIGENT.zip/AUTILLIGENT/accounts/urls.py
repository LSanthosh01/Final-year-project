from django.urls import path
from . import views

urlpatterns = [
    path('', views.home,name="home"),
    path('login/', views.loginPage,name="login"),
    path('logout/', views.logoutUser,name="logout"),
    path('register/', views.registerPage,name="register"),
    path('connect/', views.connect,name="connect"),
    path('memorycard/', views.memorycard,name="memorycard"),
    path('numberpuzzle/', views.numberpuzzle,name="numberpuzzle"),
    path('picturepuzzle/', views.picturepuzzle,name="picturepuzzle"),
    path('wordscrible/', views.wordscrible,name="wordscrible"),
    path('boxgame/', views.boxgame,name="boxgame"),
    path('smart/', views.smart,name="smart"),
    path('brillent/', views.brillent,name="brillent"),
    path('intelligent/', views.intelligent,name="intelligent"),





]